// Painel "Gerar textos com IA" do editor. Envia somente as fotografias marcadas, reduzidas a JPEG,
// ao endpoint /api/copywriting; o resultado validado só substitui textos após confirmação.
import { h } from '../core/dom.js';
import { obterOriginal, obterDerivado } from '../biblioteca/fotos.js';
import { fotoDoSlot } from '../render/composicao.js';
import { MAX_FOTOS, camposGeraveis, validarResposta } from './contrato.js';

const CHAVE_CONSENTIMENTO = 'mare.consentimentoIA.v1';
const LADO_MAX = 1280;
export const ENDPOINT = '/api/copywriting';

const vazio = (v) => v == null || (Array.isArray(v) ? v.every((it) => !it || Object.values(it).every((x) => typeof x !== 'string' || !x.trim())) : !String(v).trim());
export const temTextos = (ficha, campos) => camposGeraveis(ficha, campos).some((d) => !vazio(campos[d.id]));

const lerConsentimento = () => { try { return localStorage.getItem(CHAVE_CONSENTIMENTO) === 'sim'; } catch { return false; } };
const gravarConsentimento = (sim) => { try { sim ? localStorage.setItem(CHAVE_CONSENTIMENTO, 'sim') : localStorage.removeItem(CHAVE_CONSENTIMENTO); } catch { /* sem armazenamento */ } };

async function paraJpeg(blob) {
  const bmp = await createImageBitmap(blob);
  const k = Math.min(1, LADO_MAX / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height); bmp.close?.();
  const out = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.82));
  const buf = new Uint8Array(await out.arrayBuffer());
  let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
  return { mime: 'image/jpeg', data: btoa(bin) };
}

function confirmar(titulo, texto, ok) {
  return new Promise((resolve) => {
    const sim = h('button', { type: 'button', classe: 'botao botao--pequeno', 'data-confirmar-sim': '' }, ok);
    const nao = h('button', { type: 'button', classe: 'botao botao--secundario botao--pequeno', 'data-confirmar-nao': '' }, 'Cancelar');
    const dlg = h('dialog', { classe: 'seletor ia-confirmar', 'aria-label': titulo, 'data-confirmar': '' },
      h('h2', {}, titulo), h('p', {}, texto), h('div', { classe: 'ia__acoes' }, sim, nao));
    let res = false;
    sim.addEventListener('click', () => { res = true; dlg.close(); });
    nao.addEventListener('click', () => dlg.close());
    dlg.addEventListener('close', () => { dlg.remove(); resolve(res); });
    document.body.append(dlg); dlg.showModal();
  });
}

// ctx: { projeto(): p, ficha(): ficha, aplicar(campos), registrarUrl(url) }
export function painelIA(ctx) {
  const sec = h('section', { classe: 'painel__bloco ia', 'data-ia': '' }, h('h3', {}, 'Gerar textos com IA'));
  const ficha = ctx.ficha();
  if (ficha.id === 'INS-02') {
    sec.append(h('p', { classe: 'nota' }, 'Este modelo usa somente avaliações reais cadastradas e autorizadas. A IA não cria nem reescreve depoimentos.'));
    return { secao: sec, atualizar() {} };
  }
  const fotos = h('div', { classe: 'ia__fotos', role: 'group', 'aria-label': 'Fotografias para a IA', 'data-ia-fotos': '' });
  const objetivo = h('textarea', { rows: '2', maxlength: '1500', 'data-ia-objetivo': '', placeholder: 'Ex.: divulgar a cabana com vista para o verde na baixa temporada' });
  const inspiracao = h('textarea', { rows: '2', maxlength: '1500', 'data-ia-inspiracao': '', placeholder: 'Opcional: tom, ideia ou referência' });
  const consent = h('input', { type: 'checkbox', 'data-ia-consentimento': '' }); consent.checked = lerConsentimento();
  consent.addEventListener('change', () => gravarConsentimento(consent.checked));
  const gerar = h('button', { type: 'button', classe: 'botao botao--pequeno', 'data-ia-gerar': '' }, 'Gerar textos');
  const cancelar = h('button', { type: 'button', classe: 'botao botao--secundario botao--pequeno', 'data-ia-cancelar': '', hidden: '' }, 'Cancelar');
  const msg = h('p', { classe: 'nota ia__msg', role: 'status', 'data-ia-status': '' });
  sec.append(
    h('p', { classe: 'nota' }, `Marque até ${MAX_FOTOS} fotografias deste projeto. Só elas são enviadas; os originais ficam no seu navegador.`),
    fotos,
    h('label', { classe: 'campo' }, h('span', { classe: 'campo__rotulo' }, 'Objetivo da publicação (obrigatório)'), objetivo),
    h('label', { classe: 'campo' }, h('span', { classe: 'campo__rotulo' }, 'Inspiração'), inspiracao),
    h('label', { classe: 'campo campo--check nota' }, consent, h('span', {}, 'Autorizo enviar as fotografias marcadas a um serviço de IA (Google Gemini, Groq ou OpenRouter) somente para gerar estes textos.')),
    h('div', { classe: 'ia__acoes' }, gerar, cancelar), msg);

  const marcadas = new Set();
  let ultimas = '';
  let controlador = null;
  const aviso = (t, erro = false) => { msg.textContent = t; msg.dataset.estado = erro ? 'erro' : ''; };

  function atualizar() {
    const p = ctx.projeto();
    const ids = [...new Set(ficha.campos.filter((d) => d.tipo === 'foto').map((d) => fotoDoSlot(p, d.slot ?? 1)).filter(Boolean))];
    const chave = ids.join('|');
    if (chave === ultimas) return; ultimas = chave;
    for (const id of [...marcadas]) if (!ids.includes(id)) marcadas.delete(id);
    if (!marcadas.size) ids.slice(0, MAX_FOTOS).forEach((id) => marcadas.add(id));
    if (!ids.length) { fotos.replaceChildren(h('span', { classe: 'nota' }, 'Escolha ao menos uma fotografia no projeto para gerar textos.')); return; }
    fotos.replaceChildren(...ids.map((id) => {
      const cb = h('input', { type: 'checkbox', 'data-ia-foto': id }); cb.checked = marcadas.has(id);
      cb.addEventListener('change', () => {
        if (cb.checked && marcadas.size >= MAX_FOTOS) { cb.checked = false; aviso(`Selecione no máximo ${MAX_FOTOS} fotografias.`, true); return; }
        cb.checked ? marcadas.add(id) : marcadas.delete(id);
      });
      const img = h('img', { alt: 'Fotografia do projeto' });
      obterDerivado(id, 'miniatura').then((b) => { if (b) { const u = URL.createObjectURL(b); ctx.registrarUrl(u); img.src = u; } }).catch(() => {});
      return h('label', { classe: 'ia__foto' }, cb, img);
    }));
  }

  async function executar() {
    const p = ctx.projeto();
    if (!objetivo.value.trim()) { aviso('Informe o objetivo da publicação.', true); objetivo.focus(); return; }
    if (!marcadas.size) { aviso('Marque ao menos uma fotografia.', true); return; }
    if (!consent.checked) { aviso('Para gerar, autorize o envio das fotografias marcadas.', true); consent.focus(); return; }
    gerar.disabled = true; cancelar.hidden = false; aviso('Preparando fotografias…');
    controlador = new AbortController();
    try {
      const imagens = [];
      for (const id of marcadas) { const b = await obterOriginal(id); if (!b) throw new Error('foto'); imagens.push(await paraJpeg(b)); }
      const camposAtuais = Object.fromEntries(Object.entries(p.campos).filter(([k]) => ficha.campos.some((d) => d.id === k)));
      const pedido = { templateId: ficha.id, formato: p.formato, objetivo: objetivo.value.trim(), inspiracao: inspiracao.value.trim(), consentimento: true, fotos: imagens, campos: camposAtuais };
      aviso('Enviando ao serviço de IA…');
      const r = await fetch(ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(pedido), signal: controlador.signal });
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw Object.assign(new Error('http'), { mensagem: j.mensagem ?? 'O serviço de textos não respondeu. Os seus dados foram preservados.' }); }
      const resultado = await lerEventos(r, (e) => {
        if (e.tipo === 'provedor') aviso(e.anterior ? `${e.anterior} indisponível. Tentando ${e.provedor}…` : `Tentando ${e.provedor}…`);
      });
      // Revalida no navegador com as mesmas regras do servidor antes de tocar nos campos.
      const campos = validarResposta({ campos: resultado.campos }, ficha, ctx.projeto().campos);
      if (temTextos(ficha, ctx.projeto().campos)
        && !(await confirmar('Substituir textos?', 'Este projeto já tem textos preenchidos. Deseja substituí-los pelos textos gerados? Fotografias, enquadramento e cores não mudam.', 'Substituir'))) {
        aviso('Textos gerados descartados. Os seus textos foram mantidos.'); return;
      }
      ctx.aplicar(campos);
      aviso(`Textos gerados com sucesso por ${resultado.provedor}${resultado.fallback ? ' (serviço alternativo)' : ''}. Revise antes de exportar.`);
    } catch (e) {
      if (controlador?.signal.aborted) aviso('Geração cancelada. Nada foi alterado.');
      else aviso(e?.mensagem ?? e?.message ?? 'Não foi possível gerar os textos. Os seus dados foram preservados.', true);
      if (!e?.mensagem && !(e?.codigo)) console.error('IA:', e);
    } finally { gerar.disabled = false; cancelar.hidden = true; controlador = null; }
  }

  gerar.addEventListener('click', executar);
  cancelar.addEventListener('click', () => controlador?.abort());
  return { secao: sec, atualizar, cancelar: () => controlador?.abort() };
}

async function lerEventos(r, aoEvento) {
  const reader = r.body.getReader(), dec = new TextDecoder();
  let buf = '', final = null;
  const linha = (l) => {
    if (!l.trim()) return;
    const e = JSON.parse(l); aoEvento(e);
    if (e.tipo === 'erro') throw Object.assign(new Error(e.codigo), { mensagem: e.mensagem, codigo: e.codigo });
    if (e.tipo === 'resultado') final = e;
  };
  while (true) {
    const { value, done } = await reader.read();
    buf += dec.decode(value, { stream: !done });
    let i; while ((i = buf.indexOf('\n')) >= 0) { linha(buf.slice(0, i)); buf = buf.slice(i + 1); }
    if (done) break;
  }
  linha(buf);
  if (!final) throw Object.assign(new Error('vazio'), { mensagem: 'A geração terminou sem textos. Nada foi substituído.' });
  return final;
}
