import { createFileRoute } from '@tanstack/react-router';

// Mesma lógica da Netlify Function (netlify/functions/copywriting.mts); aqui serve a prévia.
async function tratar(request: Request) {
  const { tratarCopywriting, lerOrigens } = await import('../../lib/copywriting-handler.server');
  // Secrets lidos exclusivamente dentro do handler, nunca em módulos isomórficos.
  return tratarCopywriting(request, {
    keys: { gemini: process.env['GEMINI_API_KEY'], groq: process.env['GROQ_API_KEY'], openrouter: process.env['OPENROUTER_API_KEY'] },
    origensPermitidas: lerOrigens(process.env['ALLOWED_ORIGINS']),
  });
}

export const Route = createFileRoute('/api/copywriting')({
  server: { handlers: { POST: ({ request }) => tratar(request), OPTIONS: ({ request }) => tratar(request) } },
});
