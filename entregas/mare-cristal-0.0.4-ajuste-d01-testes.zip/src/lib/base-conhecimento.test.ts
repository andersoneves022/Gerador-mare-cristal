import { describe, expect, it, vi } from 'vitest';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { BASE_CONHECIMENTO, TEXTO_BASE, conferirFatos } from './base-conhecimento.server';
import { KNOWLEDGE, PROVIDERS } from './copywriting-config.server';
import { gerarCopy } from './copywriting.server';
import { obterFicha } from '../legacy/render/templates/index.js';
import { camposGeraveis, type Ficha } from '../legacy/ia/contrato.js';

const ficha = obterFicha('FOT-01') as Ficha & { padroes: () => Record<string, unknown> };
const campos = ficha.padroes();
const pedido = { templateId: 'FOT-01', formato: ficha.formatos[0]!, objetivo: 'Divulgar a Vila Privativa para grupos no Carnaval', inspiracao: '', consentimento: true, fotos: [{ mime: 'image/jpeg', data: 'AAAA' }], campos };
const todas = { gemini: 'g', groq: 'q', openrouter: 'o' };

function resposta(texto: string) {
  const c: Record<string, unknown> = {};
  for (const d of camposGeraveis(ficha, campos)) c[d.id] = d.tipo === 'lista' || d.tipo === 'itens' ? [] : texto;
  return { campos: c };
}
const sseGemini = (obj: unknown) => new Response(`data: ${JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify(obj) }] }, finishReason: 'STOP' }] })}\n\n`);
const sseOpenAI = (obj: unknown) => new Response(`data: ${JSON.stringify({ choices: [{ delta: { content: JSON.stringify(obj) }, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`);
const modelos = () => Response.json({ data: [{ id: PROVIDERS[2].model, pricing: { prompt: '0', completion: '0' }, architecture: { input_modalities: ['image'] }, supported_parameters: ['structured_outputs'] }] });

// Extrai (sistema, mensagem do usuário, fotos) do corpo de cada provedor, no formato de cada API.
function contexto(url: string, body: string) {
  const j = JSON.parse(body);
  if (url.includes('generativelanguage')) {
    const parts = j.contents[0].parts;
    return { sistema: j.systemInstruction.parts[0].text, usuario: parts[0].text, fotos: parts.slice(1).map((x: { inlineData: { data: string } }) => x.inlineData.data) };
  }
  const user = j.messages.find((m: { role: string }) => m.role === 'user').content;
  return { sistema: j.messages.find((m: { role: string }) => m.role === 'system').content, usuario: user[0].text, fotos: user.slice(1).map((x: { image_url: { url: string } }) => x.image_url.url.split(',')[1]) };
}

describe('base de conhecimento', () => {
  it('1. is loaded in full and the generation sections reach the system instruction', () => {
    expect(BASE_CONHECIMENTO.map((s) => s.titulo.split('.')[0])).toEqual(Array.from({ length: 15 }, (_, i) => String(i + 1)));
    expect(KNOWLEDGE).toContain(TEXTO_BASE);
    for (const fato of ['Confortável: 8 pessoas', 'Máxima: 11 pessoas', 'Praia a pé: aproximadamente 25 minutos', 'As toalhas de banho não estão incluídas', 'Estadia mínima: 2 noites', 'Quintal Butiá', '@cabanaslobodomar', 'Taxa para pets'])
      expect(TEXTO_BASE).toContain(fato);
    // Seções do futuro agente (painel, autonomia, campanhas) não orientam esta geração.
    expect(TEXTO_BASE).not.toContain('painel administrativo');
    expect(TEXTO_BASE).not.toContain('11.2. Escolha de fotografias');
  });

  it('stays on the server: no browser module imports it', () => {
    const arquivos = (d: string): string[] => readdirSync(d).flatMap((f) => statSync(join(d, f)).isDirectory() ? arquivos(join(d, f)) : [join(d, f)]);
    for (const f of arquivos('src/legacy')) expect(readFileSync(f, 'utf8'), f).not.toMatch(/base-conhecimento|copywriting-config/);
  });

  it('2. Gemini, Groq and OpenRouter receive exactly the same context', async () => {
    const vistos: ReturnType<typeof contexto>[] = [];
    const fetcher = vi.fn(async (url: string, init: RequestInit) => {
      if (url.endsWith('/models')) return modelos();
      vistos.push(contexto(url, String(init.body)));
      return url.includes('openrouter') ? sseOpenAI(resposta('Vila inteira para a turma')) : new Response('', { status: 429 });
    });
    await gerarCopy(pedido, todas, new AbortController().signal, () => {}, fetcher as unknown as typeof fetch);
    expect(vistos).toHaveLength(3);
    expect(vistos[0]!.sistema).toBe(KNOWLEDGE);
    expect(vistos[1]).toEqual(vistos[0]);
    expect(vistos[2]).toEqual(vistos[0]);
    expect(vistos[0]!.usuario).toContain(pedido.objetivo);
    expect(vistos[0]!.fotos).toEqual(['AAAA']);
  });

  it('3. checks generated texts against the real data', () => {
    const dados = `${pedido.objetivo}`;
    expect(conferirFatos({ titulo: 'Vila com piscina para a turma' }, dados)).toMatch(/comodidade/);
    expect(conferirFatos({ titulo: 'Wi-Fi rápido' }, dados)).toMatch(/comodidade/);
    expect(conferirFatos({ faq: [{ p: 'Tem ar-condicionado?', r: 'Tem sim, em todas' }] }, dados)).toMatch(/comodidade/);
    expect(conferirFatos({ faq: [{ p: 'Tem toalhas?', r: 'Não, as toalhas de banho não estão incluídas' }] }, dados)).toBeNull();
    expect(conferirFatos({ r: 'As toalhas de banho não estão incluídas' }, dados)).toBeNull();
    expect(conferirFatos({ titulo: 'Caminhe até a praia' }, dados)).toMatch(/praia/);
    expect(conferirFatos({ apoio: 'A praia fica a 10 minutos de carro' }, dados)).toBeNull();
    expect(conferirFatos({ apoio: 'Diárias a partir de R$ 450' }, dados)).toMatch(/valor/);
    expect(conferirFatos({ apoio: 'Vila a partir de R$ 700 em dias de semana' }, dados)).toBeNull();
    expect(conferirFatos({ apoio: 'Feriado por R$ 1.200' }, 'Divulgar feriado com diária de R$ 1.200')).toBeNull();
    expect(conferirFatos({ titulo: 'Até 11 pessoas na Vila Privativa' }, dados)).toBeNull();
  });

  it('4/5. an invented amenity sends the request to the next provider, which fills the fields', async () => {
    const chamadas: string[] = [];
    const fetcher = vi.fn(async (url: string) => {
      if (url.endsWith('/models')) return modelos();
      chamadas.push(url.includes('generativelanguage') ? 'gemini' : url.includes('groq') ? 'groq' : 'openrouter');
      return url.includes('generativelanguage') ? sseGemini(resposta('Vila com piscina')) : sseOpenAI(resposta('Quintal e churrasqueira'));
    });
    const eventos: Record<string, unknown>[] = [];
    await gerarCopy(pedido, todas, new AbortController().signal, (e) => eventos.push(e), fetcher as unknown as typeof fetch);
    expect(chamadas).toEqual(['gemini', 'groq']);
    const r = eventos.find((e) => e['tipo'] === 'resultado')!;
    expect(r['provedor']).toBe('Groq');
    expect(Object.keys(r['campos'] as object).sort()).toEqual(camposGeraveis(ficha, campos).map((d) => d.id).sort());
    expect(Object.values(r['campos'] as object)).toContain('Quintal e churrasqueira');
  });
});
