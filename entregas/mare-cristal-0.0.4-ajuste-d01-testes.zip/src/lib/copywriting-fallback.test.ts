import { describe, expect, it, vi } from 'vitest';
import { gerarCopy } from './copywriting.server';
import { PROVIDERS } from './copywriting-config.server';
import { obterFicha } from '../legacy/render/templates/index.js';
import { camposGeraveis, ErroCopy, type Ficha } from '../legacy/ia/contrato.js';

const ficha = obterFicha('FOT-01') as Ficha & { padroes: () => Record<string, unknown> };
const campos = ficha.padroes();
const pedido = { templateId: 'FOT-01', formato: ficha.formatos[0]!, objetivo: 'Divulgar a cabana', inspiracao: '', consentimento: true, fotos: [{ mime: 'image/jpeg', data: 'AAAA' }], campos };
const todas = { gemini: 'g', groq: 'q', openrouter: 'o' };

function respostaValida(texto = 'Texto curto') {
  const c: Record<string, unknown> = {};
  for (const d of camposGeraveis(ficha, campos)) c[d.id] = d.tipo === 'lista' || d.tipo === 'itens' ? [] : texto;
  return { campos: c };
}
const sseGemini = (obj: unknown) => new Response(`data: ${JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify(obj) }] }, finishReason: 'STOP' }] })}\n\n`, { status: 200 });
const sseOpenAI = (obj: unknown) => new Response(`data: ${JSON.stringify({ choices: [{ delta: { content: JSON.stringify(obj) }, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`, { status: 200 });
const modelosOpenRouter = () => Response.json({ data: [{ id: PROVIDERS[2].model, pricing: { prompt: '0', completion: '0' }, architecture: { input_modalities: ['text', 'image'] }, supported_parameters: ['structured_outputs'] }] });

type Rota = 'gemini' | 'groq' | 'openrouter';
const rota = (url: string): Rota | 'modelos' => url.includes('generativelanguage') ? 'gemini' : url.includes('groq.com') ? 'groq' : url.endsWith('/models') ? 'modelos' : 'openrouter';

// Simula cada provedor; registra quantas vezes cada um foi chamado.
function simular(resp: Partial<Record<Rota, () => Response>>) {
  const chamadas: Rota[] = [];
  const fetcher = vi.fn(async (url: string) => {
    const r = rota(url);
    if (r === 'modelos') return modelosOpenRouter();
    chamadas.push(r);
    return resp[r]!();
  });
  return { fetcher: fetcher as unknown as typeof fetch, chamadas, raw: fetcher };
}
async function gerar(keys: Record<string, string>, fetcher: typeof fetch) {
  const eventos: Record<string, unknown>[] = [];
  await gerarCopy(pedido, keys, new AbortController().signal, (e) => eventos.push(e), fetcher);
  return eventos;
}
const resultado = (ev: Record<string, unknown>[]) => ev.find((e) => e['tipo'] === 'resultado')!;

describe('fallback Gemini → Groq → OpenRouter', () => {
  it('1. Gemini working: no other provider is called', async () => {
    const s = simular({ gemini: () => sseGemini(respostaValida()) });
    const ev = await gerar(todas, s.fetcher);
    expect(s.chamadas).toEqual(['gemini']);
    expect(resultado(ev)).toMatchObject({ provedor: 'Google Gemini', fallback: false });
  });

  it('2. Gemini with invalid key (401): tries Groq', async () => {
    const s = simular({ gemini: () => new Response('', { status: 401 }), groq: () => sseOpenAI(respostaValida()) });
    const ev = await gerar(todas, s.fetcher);
    expect(s.chamadas).toEqual(['gemini', 'groq']);
    expect(resultado(ev)).toMatchObject({ provedor: 'Groq', fallback: true });
    expect(ev).toContainEqual({ tipo: 'provedor', provedor: 'Groq', anterior: 'Google Gemini' });
  });

  it('3. Gemini with unauthorized/missing model (403, 404, 400): tries Groq', async () => {
    for (const status of [403, 404, 400]) {
      const s = simular({ gemini: () => new Response('', { status }), groq: () => sseOpenAI(respostaValida()) });
      await gerar(todas, s.fetcher);
      expect(s.chamadas).toEqual(['gemini', 'groq']);
    }
  });

  it('4. Gemini and Groq failing: tries OpenRouter, one attempt each', async () => {
    const s = simular({ gemini: () => new Response('', { status: 403 }), groq: () => new Response('', { status: 429 }), openrouter: () => sseOpenAI(respostaValida()) });
    const ev = await gerar(todas, s.fetcher);
    expect(s.chamadas).toEqual(['gemini', 'groq', 'openrouter']);
    expect(resultado(ev)).toMatchObject({ provedor: 'OpenRouter', fallback: true });
    expect(ev).toContainEqual({ tipo: 'provedor', provedor: 'OpenRouter', anterior: 'Groq' });
  });

  it('4b. invalid structured response, 5xx and network errors also fall back', async () => {
    const s = simular({ gemini: () => sseGemini({ outra: 1 }), groq: () => new Response('', { status: 503 }), openrouter: () => sseOpenAI(respostaValida()) });
    await gerar(todas, s.fetcher);
    expect(s.chamadas).toEqual(['gemini', 'groq', 'openrouter']);
    const t = simular({ gemini: () => { throw new TypeError('rede'); }, groq: () => sseOpenAI(respostaValida()) });
    await gerar(todas, t.fetcher);
    expect(t.chamadas).toEqual(['gemini', 'groq']);
  });

  it('5. Groq without key: skipped, goes to OpenRouter', async () => {
    const s = simular({ gemini: () => new Response('', { status: 429 }), openrouter: () => sseOpenAI(respostaValida()) });
    const ev = await gerar({ gemini: 'g', openrouter: 'o' }, s.fetcher);
    expect(s.chamadas).toEqual(['gemini', 'openrouter']);
    expect(resultado(ev)['provedor']).toBe('OpenRouter');
  });

  it('6. all failing: understandable error with reasons and no secrets', async () => {
    const s = simular({ gemini: () => new Response('chave-secreta', { status: 401 }), groq: () => new Response('', { status: 429 }), openrouter: () => new Response('', { status: 502 }) });
    const erro = await gerarCopy(pedido, todas, new AbortController().signal, () => {}, s.fetcher).catch((e) => e);
    expect(erro).toBeInstanceOf(ErroCopy);
    expect(erro.message).toMatch(/Nenhum provedor conseguiu gerar o texto/);
    expect(erro.message).toMatch(/Google Gemini: .*não autorizou/);
    expect(erro.message).toMatch(/Groq: .*cota gratuita/);
    expect(erro.message).toMatch(/OpenRouter: .*indisponível/);
    expect(erro.message).not.toContain('chave-secreta');
    expect(s.chamadas).toEqual(['gemini', 'groq', 'openrouter']);
  });

  it('7. next provider working: fills the real editor fields', async () => {
    const s = simular({ gemini: () => new Response('', { status: 404 }), groq: () => sseOpenAI(respostaValida('Cabana no verde')) });
    const ev = await gerar(todas, s.fetcher);
    const gerados = resultado(ev)['campos'] as Record<string, unknown>;
    expect(Object.keys(gerados).sort()).toEqual(camposGeraveis(ficha, campos).map((d) => d.id).sort());
    expect(Object.values(gerados).filter((v) => typeof v === 'string')).toContain('Cabana no verde');
  });

  it('8. local validation errors: no provider is called', async () => {
    const s = simular({});
    for (const p of [{ ...pedido, objetivo: '' }, { ...pedido, fotos: [] }, { ...pedido, consentimento: false }, { ...pedido, formato: 'xx' }])
      await expect(gerarCopy(p, todas, new AbortController().signal, () => {}, s.fetcher)).rejects.toBeInstanceOf(ErroCopy);
    expect(s.raw).not.toHaveBeenCalled();
  });

  it('content safety refusal stops without trying other providers', async () => {
    const s = simular({ gemini: () => new Response(`data: ${JSON.stringify({ promptFeedback: { blockReason: 'SAFETY' } })}\n\n`) });
    await expect(gerar(todas, s.fetcher)).rejects.toMatchObject({ codigo: 'recusa' });
    expect(s.chamadas).toEqual(['gemini']);
  });
});

describe('timeout', () => {
  it('a hanging provider times out and the next one is tried', async () => {
    vi.useFakeTimers();
    try {
      const chamadas: string[] = [];
      const fetcher = (async (url: string, init: RequestInit) => {
        if (url.endsWith('/models')) return modelosOpenRouter();
        chamadas.push(rota(url));
        if (rota(url) === 'gemini') return new Promise((_, rej) => init.signal!.addEventListener('abort', () => rej(new DOMException('t', 'TimeoutError'))));
        return sseOpenAI(respostaValida());
      }) as unknown as typeof fetch;
      const p = gerarCopy(pedido, todas, new AbortController().signal, () => {}, fetcher);
      await vi.advanceTimersByTimeAsync(26_000);
      await p;
      expect(chamadas).toEqual(['gemini', 'groq']);
    } finally { vi.useRealTimers(); }
  });
});
