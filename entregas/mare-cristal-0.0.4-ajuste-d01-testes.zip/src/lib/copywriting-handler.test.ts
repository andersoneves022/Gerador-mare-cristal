import { describe, expect, it, vi, afterEach } from 'vitest';
import { tratarCopywriting } from './copywriting-handler.server';
import { gerarCopy } from './copywriting.server';
import { obterFicha } from '../legacy/render/templates/index.js';
import { camposGeraveis, type Ficha } from '../legacy/ia/contrato.js';

const ORIGEM = 'https://mare.netlify.app';
const ficha = obterFicha('FOT-01') as Ficha & { padroes: () => Record<string, unknown> };
const campos = ficha.padroes();
const pedido = { templateId: 'FOT-01', formato: ficha.formatos[0]!, objetivo: 'Divulgar a cabana', inspiracao: '', consentimento: true, fotos: [{ mime: 'image/jpeg', data: 'AAAA' }], campos };

function respostaValida() {
  const c: Record<string, unknown> = {};
  for (const d of camposGeraveis(ficha, campos)) c[d.id] = d.tipo === 'lista' || d.tipo === 'itens' ? [] : 'Texto curto';
  return { campos: c };
}
const sseGemini = (obj: unknown) => new Response(`data: ${JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify(obj) }] }, finishReason: 'STOP' }] })}\n\n`, { status: 200 });
const req = (origin: string | null, body = pedido) => new Request(`${ORIGEM}/api/copywriting`, { method: 'POST', headers: { 'content-type': 'application/json', ...(origin ? { origin } : {}) }, body: JSON.stringify(body) });

afterEach(() => vi.unstubAllGlobals());

describe('copywriting endpoint', () => {
  it('rejects requests from unauthorized origins', async () => {
    const r = await tratarCopywriting(req('https://outro-site.com'), { keys: { gemini: 'k' } });
    expect(r.status).toBe(403);
  });

  it('answers CORS preflight only for an allowed origin', async () => {
    const r = await tratarCopywriting(new Request(`https://fn.netlify.app/api/copywriting`, { method: 'OPTIONS', headers: { origin: ORIGEM } }), { keys: {}, origensPermitidas: [ORIGEM] });
    expect(r.status).toBe(204);
    expect(r.headers.get('access-control-allow-origin')).toBe(ORIGEM);
  });

  it('never echoes provider keys to the browser', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('erro com chave-secreta-123', { status: 500 })));
    const r = await tratarCopywriting(req(ORIGEM), { keys: { gemini: 'chave-secreta-123' } });
    const txt = await r.text();
    expect(txt).not.toContain('chave-secreta-123');
  });
});

describe('provider order and fallback', () => {
  it('uses Gemini first and returns validated fields', async () => {
    const fetcher = vi.fn(async () => sseGemini(respostaValida()));
    const eventos: Record<string, unknown>[] = [];
    await gerarCopy(pedido, { gemini: 'g', openrouter: 'o' }, new AbortController().signal, (e) => eventos.push(e), fetcher as unknown as typeof fetch);
    expect(String((fetcher.mock.calls[0] as unknown[])[0])).toContain('generativelanguage.googleapis.com');
    expect(eventos.find((e) => e['tipo'] === 'resultado')?.['provedor']).toBe('Google Gemini');
  });

  it('skips providers whose key is missing instead of calling them', async () => {
    const fetcher = vi.fn();
    await expect(gerarCopy(pedido, {}, new AbortController().signal, () => {}, fetcher as unknown as typeof fetch)).rejects.toThrow(/Nenhum provedor conseguiu/);
    expect(fetcher).not.toHaveBeenCalled();
  });
});
